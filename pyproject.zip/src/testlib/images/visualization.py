import logging
logger = logging.getLogger(__name__)

def show():
    logger.info("Función para mostrar una imagen")
import logging
logging.basicConfig(level=logging.ERROR)
import numpy as np

# from testlib.images import transform
# transform.conv2D()
# transform.modifyContrast()

# from testlib.images.transform import conv2D, modifyContrast
# conv2D()
# modifyContrast()

from testlib.images.transform import *
conv2D()
modifyContrast()
